import { useState } from 'react';
import { MotionConfig } from 'framer-motion';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { SocialProof } from './components/SocialProof';
import { FeaturesSection } from './components/FeaturesSection';
import { ProductShowcase } from './components/ProductShowcase';
import { BenefitsSection } from './components/BenefitsSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { PricingSection } from './components/PricingSection';
import { FaqSection } from './components/FaqSection';
import { CtaSection } from './components/CtaSection';
import { Footer } from './components/Footer';
import { JoinModal } from './components/JoinModal';

export function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'join' | 'share'>('join');
  const [prefilledHandle, setPrefilledHandle] = useState('');
  const [selectedPlan, setSelectedPlan] = useState('Community Fan');

  const handleOpenModal = (mode: 'join' | 'share') => {
    setModalMode(mode);
    setModalOpen(true);
  };

  const handleSelectPlan = (planName: string) => {
    setSelectedPlan(planName);
    setModalMode('join');
    setModalOpen(true);
  };

  const handleClaimHandle = (handle: string) => {
    setPrefilledHandle(handle);
    setSelectedPlan('Community Fan');
    setModalMode('join');
    setModalOpen(true);
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#FAFAFA] text-zinc-950 flex flex-col">
        <Navbar onOpenModal={handleOpenModal} />

        <main className="flex-1">
          <HeroSection onOpenModal={handleOpenModal} />
          <SocialProof />
          <FeaturesSection />
          <ProductShowcase onOpenModal={handleOpenModal} />
          <BenefitsSection />
          <TestimonialsSection />
          <PricingSection onSelectPlan={handleSelectPlan} />
          <FaqSection />
          <CtaSection onClaimHandle={handleClaimHandle} />
        </main>

        <Footer />

        <JoinModal
          isOpen={modalOpen}
          initialMode={modalMode}
          prefilledHandle={prefilledHandle}
          selectedPlan={selectedPlan}
          onClose={() => setModalOpen(false)}
        />
      </div>
    </MotionConfig>
  );
}

export default App;
