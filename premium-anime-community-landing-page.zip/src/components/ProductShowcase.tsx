import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Flame,
  MessageSquare,
  Heart,
  Swords,
  Radio,
  Sparkles,
  Send,
  ShieldAlert,
  Award,
  Upload,
} from 'lucide-react';
import {
  FEATURED_CLIPS,
  ENEMY_DOSSIERS,
  type ClipPost,
} from '../data/animeContent';
import { CelReveal, SAKUGA_EASE } from './MotionPrimitives';

interface ProductShowcaseProps {
  onOpenModal: (mode: 'join' | 'share') => void;
}

type TabKey = 'feed' | 'codex' | 'lounge';

export const ProductShowcase: React.FC<ProductShowcaseProps> = ({
  onOpenModal,
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('feed');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [likedIds, setLikedIds] = useState<Record<string, boolean>>({
    'clip-2': true,
  });

  // Enemy Codex interactive state
  const [selectedEnemyIdx, setSelectedEnemyIdx] = useState(0);
  const [endorsedEnemies, setEndorsedEnemies] = useState<Record<string, boolean>>({});

  // Live Lounge interactive poll & chat state
  const [votedOption, setVotedOption] = useState<number | null>(0);
  const [pollVotes, setPollVotes] = useState([54, 31, 15]);
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState([
    {
      id: 1,
      user: '@kenji_frames',
      avatar: '/images/avatar-kenji.jpg',
      badge: 'Sakuga Mod',
      time: '19:42',
      text: 'Did everyone catch the 3-frame black-and-white impact flash right before the sword parry?!',
    },
    {
      id: 2,
      user: '@haruka_mecha',
      avatar: '/images/avatar-haruka.jpg',
      badge: 'Guild Host',
      time: '54:10',
      text: 'Unit-09 walking out of the bay mist with zero music is peak anime villain direction.',
    },
    {
      id: 3,
      user: '@ren_cuts',
      avatar: '/images/avatar-ren.jpg',
      badge: 'Key Animator',
      time: '21:14',
      text: 'Uploaded the lossless 10-bit WebM comparison to the Enemy Codex thread! Zero banding.',
    },
  ]);

  const categories = ['All', 'Enemy Showdown', 'Rival Clash', 'Visual Aesthetics'];

  const filteredClips: ClipPost[] =
    selectedCategory === 'All'
      ? FEATURED_CLIPS
      : FEATURED_CLIPS.filter((c) => c.category === selectedCategory);

  const toggleLike = (id: string) => {
    setLikedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleVotePoll = (idx: number) => {
    setVotedOption(idx);
    const updated = [53, 31, 16];
    updated[idx] += 2;
    const sum = updated.reduce((a, b) => a + b, 0);
    setPollVotes(updated.map((v) => Math.round((v / sum) * 100)));
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = chatInput.trim();
    if (!trimmed) return;
    setChatMessages((prev) => [
      ...prev,
      {
        id: Date.now(),
        user: '@you_guest',
        avatar: '/images/avatar-kenji.jpg',
        badge: 'New Fan',
        time: 'LIVE',
        text: trimmed,
      },
    ]);
    setChatInput('');
  };

  const currentEnemy = ENEMY_DOSSIERS[selectedEnemyIdx];

  return (
    <section
      id="showcase"
      className="border-y border-zinc-200/80 bg-zinc-50/75 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <CelReveal className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-zinc-200 bg-white px-3.5 py-1 text-xs font-bold tracking-wide text-zinc-700 uppercase shadow-2xs">
            <Flame className="h-3.5 w-3.5 text-rose-600" />
            <span>Interactive Community Showcase</span>
          </span>
          <h2 className="mt-4 text-3xl font-extrabold tracking-[-0.035em] text-zinc-950 sm:text-5xl">
            Step inside the community feed.
          </h2>
          <p className="mt-4 text-base text-zinc-600 sm:text-lg">
            Test drive how fans share lossless clips, curate iconic anime enemies,
            and hype weekly episodes live.
          </p>
        </CelReveal>

        {/* Interactive Tab Switcher */}
        <div className="mt-10 flex justify-center">
          <div
            role="tablist"
            aria-label="Community Showcase Views"
            className="inline-flex flex-wrap justify-center gap-1 rounded-2xl border border-zinc-200/90 bg-white p-1.5 shadow-xs"
          >
            {[
              { id: 'feed' as TabKey, label: 'Trending Clips & Sakuga', icon: Sparkles },
              { id: 'codex' as TabKey, label: 'Enemy & Rival Codex', icon: Swords },
              { id: 'lounge' as TabKey, label: 'Live Episode Lounge', icon: Radio },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={isActive}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-colors cursor-pointer ${
                    isActive ? 'text-white' : 'text-zinc-600 hover:text-zinc-950'
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="activeShowcaseTab"
                      transition={{ type: 'spring', bounce: 0.18, duration: 0.45 }}
                      className="absolute inset-0 rounded-xl bg-zinc-950 shadow-sm"
                    />
                  )}
                  <Icon
                    className={`relative z-10 h-4 w-4 ${
                      isActive ? 'text-rose-400' : 'text-zinc-400'
                    }`}
                  />
                  <span className="relative z-10">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Interactive Tab Content Surface */}
        <div className="mt-10">
          <AnimatePresence mode="wait">
            {activeTab === 'feed' && (
              <motion.div
                key="feed"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35, ease: SAKUGA_EASE }}
              >
                {/* Filter & Post Toolbar */}
                <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition cursor-pointer ${
                          selectedCategory === cat
                            ? 'bg-rose-600 text-white shadow-2xs'
                            : 'border border-zinc-200 bg-white text-zinc-600 hover:border-zinc-300 hover:text-zinc-950'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenModal('share')}
                    className="inline-flex items-center gap-1.5 rounded-full bg-zinc-950 px-4 py-2 text-xs font-semibold text-white transition hover:bg-rose-600 cursor-pointer"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    <span>Upload Your Clip</span>
                  </button>
                </div>

                {/* Clip Feed Grid */}
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  {filteredClips.map((clip) => {
                    const isLiked = !!likedIds[clip.id];
                    const totalLikes = clip.upvotes + (isLiked ? 1 : 0);

                    return (
                      <div
                        key={clip.id}
                        className="group overflow-hidden rounded-2xl border border-zinc-200/85 bg-white shadow-2xs transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-zinc-950/[0.06]"
                      >
                        <div className="relative aspect-[16/9] overflow-hidden bg-zinc-900">
                          <img
                            src={clip.image}
                            alt={clip.title}
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />

                          <div className="absolute top-3 left-3 flex items-center gap-2">
                            <span className="rounded-full bg-rose-600/95 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur-xs">
                              {clip.category}
                            </span>
                            <span className="rounded-full bg-black/60 px-2.5 py-1 font-mono text-[11px] font-medium text-white backdrop-blur-xs">
                              {clip.episodeTag}
                            </span>
                          </div>

                          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
                            <span className="font-mono text-[11px] text-zinc-200">
                              {clip.fpsSpec}
                            </span>
                            <span className="rounded bg-black/65 px-2 py-0.5 font-mono text-[11px] text-emerald-300">
                              {clip.timestamp}
                            </span>
                          </div>
                        </div>

                        <div className="p-6">
                          <div className="flex items-center justify-between text-xs text-zinc-500">
                            <span className="font-semibold text-rose-600">
                              {clip.animeTitle}
                            </span>
                            <span className="font-mono">{clip.keyAnimator}</span>
                          </div>

                          <h3 className="mt-1.5 text-lg font-bold tracking-[-0.02em] text-zinc-950">
                            {clip.title}
                          </h3>
                          <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                            {clip.description}
                          </p>

                          <div className="mt-5 flex items-center justify-between border-t border-zinc-100 pt-4">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={clip.authorAvatar}
                                alt={clip.authorName}
                                className="h-7 w-7 rounded-full object-cover ring-1 ring-zinc-200"
                              />
                              <div>
                                <p className="text-xs font-bold text-zinc-900">
                                  {clip.authorName}
                                </p>
                                <p className="text-[11px] text-zinc-400">
                                  {clip.authorHandle}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <motion.button
                                type="button"
                                whileTap={{ scale: 0.9 }}
                                onClick={() => toggleLike(clip.id)}
                                className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition cursor-pointer ${
                                  isLiked
                                    ? 'border-rose-200 bg-rose-50 text-rose-600'
                                    : 'border-zinc-200 bg-zinc-50 text-zinc-700 hover:bg-zinc-100'
                                }`}
                              >
                                <Heart
                                  className={`h-3.5 w-3.5 ${
                                    isLiked ? 'fill-rose-600 text-rose-600' : ''
                                  }`}
                                />
                                <span>{totalLikes.toLocaleString()}</span>
                              </motion.button>

                              <span className="inline-flex items-center gap-1 rounded-full border border-zinc-200 bg-white px-3 py-1.5 text-xs font-medium text-zinc-600">
                                <MessageSquare className="h-3.5 w-3.5 text-zinc-400" />
                                <span>{clip.comments}</span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {activeTab === 'codex' && (
              <motion.div
                key="codex"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35, ease: SAKUGA_EASE }}
                className="overflow-hidden rounded-3xl border border-zinc-200 bg-white shadow-sm"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12">
                  {/* Left Selector Column */}
                  <div className="border-b border-zinc-200 bg-zinc-50/70 p-6 lg:col-span-4 lg:border-r lg:border-b-0">
                    <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-zinc-400 uppercase">
                      <ShieldAlert className="h-4 w-4 text-rose-600" />
                      <span>Top Ranked Anime Enemies & Rivals</span>
                    </div>

                    <div className="mt-4 space-y-2.5">
                      {ENEMY_DOSSIERS.map((dossier, idx) => {
                        const active = selectedEnemyIdx === idx;
                        return (
                          <button
                            key={dossier.id}
                            type="button"
                            onClick={() => setSelectedEnemyIdx(idx)}
                            className={`w-full rounded-2xl border p-4 text-left transition-all cursor-pointer ${
                              active
                                ? 'border-zinc-950 bg-zinc-950 text-white shadow-md'
                                : 'border-zinc-200 bg-white text-zinc-900 hover:border-zinc-300'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span
                                className={`rounded-md px-2 py-0.5 font-mono text-[10px] font-bold ${
                                  active
                                    ? 'bg-rose-600 text-white'
                                    : 'bg-rose-50 text-rose-700'
                                }`}
                              >
                                {dossier.threatTier}
                              </span>
                              <span
                                className={`font-mono text-xs ${
                                  active ? 'text-zinc-400' : 'text-zinc-500'
                                }`}
                              >
                                #{idx + 1} Ranked
                              </span>
                            </div>
                            <p className="mt-2 text-sm font-bold">{dossier.name}</p>
                            <p
                              className={`text-xs ${
                                active ? 'text-zinc-400' : 'text-zinc-500'
                              }`}
                            >
                              {dossier.series}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right Active Dossier View */}
                  <div className="p-6 sm:p-8 lg:col-span-8">
                    <div className="relative overflow-hidden rounded-2xl aspect-[16/9]">
                      <img
                        src={currentEnemy.image}
                        alt={currentEnemy.name}
                        className="h-full w-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-end justify-between gap-3 text-white">
                        <div>
                          <span className="font-mono text-xs text-rose-400 uppercase">
                            {currentEnemy.alias} · {currentEnemy.peakEpisode}
                          </span>
                          <h3 className="text-2xl font-extrabold tracking-tight sm:text-3xl">
                            {currentEnemy.name}
                          </h3>
                        </div>
                        <span className="rounded-full bg-white/15 px-3 py-1 font-mono text-xs font-semibold backdrop-blur-md">
                          {currentEnemy.sharedClipsCount}
                        </span>
                      </div>
                    </div>

                    <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div className="rounded-xl border border-zinc-200/80 bg-zinc-50 p-4">
                        <span className="text-xs font-semibold text-zinc-500">
                          Signature Combat Style
                        </span>
                        <p className="mt-1 text-sm font-bold text-zinc-950">
                          {currentEnemy.combatStyle}
                        </p>
                      </div>
                      <div className="rounded-xl border border-zinc-200/80 bg-zinc-50 p-4">
                        <span className="text-xs font-semibold text-zinc-500">
                          Community Menace Rating
                        </span>
                        <div className="mt-1.5 flex items-center gap-3">
                          <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-zinc-200">
                            <div
                              style={{
                                width: `${
                                  currentEnemy.communityWinRate +
                                  (endorsedEnemies[currentEnemy.id] ? 1 : 0)
                                }%`,
                              }}
                              className="h-full rounded-full bg-gradient-to-r from-rose-600 to-orange-500 transition-all duration-300"
                            />
                          </div>
                          <span className="font-mono text-sm font-extrabold text-zinc-950">
                            {currentEnemy.communityWinRate +
                              (endorsedEnemies[currentEnemy.id] ? 1 : 0)}
                            %
                          </span>
                        </div>
                      </div>
                    </div>

                    <p className="mt-5 text-sm leading-relaxed text-zinc-600">
                      <strong className="text-zinc-900">Iconic Moment: </strong>
                      {currentEnemy.signatureMoment}
                    </p>

                    <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-zinc-100 pt-5">
                      <div className="flex flex-wrap gap-2">
                        {currentEnemy.tags.map((tag) => (
                          <span
                            key={tag}
                            className="rounded-full bg-zinc-100 px-3 py-1 text-xs font-semibold text-zinc-700"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          setEndorsedEnemies((prev) => ({
                            ...prev,
                            [currentEnemy.id]: !prev[currentEnemy.id],
                          }))
                        }
                        className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold transition cursor-pointer ${
                          endorsedEnemies[currentEnemy.id]
                            ? 'bg-emerald-600 text-white'
                            : 'bg-rose-600 text-white hover:bg-rose-700'
                        }`}
                      >
                        <Award className="h-4 w-4" />
                        <span>
                          {endorsedEnemies[currentEnemy.id]
                            ? 'Voted Iconic Enemy!'
                            : 'Vote Iconic Enemy (+1)'}
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'lounge' && (
              <motion.div
                key="lounge"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35, ease: SAKUGA_EASE }}
                className="grid grid-cols-1 gap-6 lg:grid-cols-12"
              >
                {/* Live Community Poll Card */}
                <div className="rounded-3xl border border-zinc-200 bg-white p-6 sm:p-8 lg:col-span-5">
                  <div className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
                    <span>LIVE WEEKLY SHOWDOWN POLL · 8,920 VOTES</span>
                  </div>

                  <h3 className="mt-4 text-xl font-extrabold tracking-[-0.02em] text-zinc-950">
                    Which anime antagonist stole the entire season in under two minutes?
                  </h3>
                  <p className="mt-1.5 text-xs text-zinc-500">
                    Click an option below to cast your live vote:
                  </p>

                  <div className="mt-6 space-y-3">
                    {[
                      'Unit-09 "Calamity" — Neo-Bay Mist Entrance',
                      'Kagura — 108 Torii Steps Reversed Barrier',
                      'Rei Kurosawa — Rain Rooftop Double Draw',
                    ].map((option, idx) => {
                      const selected = votedOption === idx;
                      const pct = pollVotes[idx];
                      return (
                        <button
                          key={option}
                          type="button"
                          onClick={() => handleVotePoll(idx)}
                          className={`relative w-full overflow-hidden rounded-xl border p-4 text-left transition cursor-pointer ${
                            selected
                              ? 'border-rose-500 bg-rose-50/40'
                              : 'border-zinc-200 bg-zinc-50/60 hover:border-zinc-300'
                          }`}
                        >
                          <div
                            style={{ width: `${pct}%` }}
                            className={`pointer-events-none absolute inset-y-0 left-0 transition-all duration-500 ${
                              selected ? 'bg-rose-500/15' : 'bg-zinc-200/50'
                            }`}
                          />
                          <div className="relative z-10 flex items-center justify-between gap-2">
                            <span className="text-xs sm:text-sm font-bold text-zinc-900">
                              {option}
                            </span>
                            <span className="font-mono text-xs font-extrabold text-rose-600">
                              {pct}%
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Live Timestamped Watch Thread */}
                <div className="flex flex-col justify-between rounded-3xl border border-zinc-200 bg-white p-6 sm:p-8 lg:col-span-7">
                  <div>
                    <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
                      <div>
                        <h3 className="text-lg font-bold text-zinc-950">
                          #seasonal-simulcast-lounge
                        </h3>
                        <p className="text-xs text-zinc-500">
                          Spoiler-synced live reaction stream · Drop a message below!
                        </p>
                      </div>
                      <span className="rounded-full bg-zinc-100 px-3 py-1 font-mono text-xs font-semibold text-zinc-700">
                        1,420 typing
                      </span>
                    </div>

                    <div className="mt-5 space-y-4 max-h-72 overflow-y-auto pr-1">
                      {chatMessages.map((msg) => (
                        <div
                          key={msg.id}
                          className="flex items-start gap-3 rounded-2xl bg-zinc-50/90 p-3.5 border border-zinc-100"
                        >
                          <img
                            src={msg.avatar}
                            alt={msg.user}
                            className="h-9 w-9 rounded-full object-cover ring-2 ring-white"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-xs font-bold text-zinc-950">
                                {msg.user}
                              </span>
                              <span className="rounded bg-rose-50 px-2 py-0.5 text-[10px] font-bold text-rose-700">
                                {msg.badge}
                              </span>
                              <span className="font-mono text-[10px] text-zinc-400">
                                @ {msg.time}
                              </span>
                            </div>
                            <p className="mt-1 text-sm text-zinc-700">{msg.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Interactive Chat Composer */}
                  <form onSubmit={handleSendChat} className="mt-5 flex gap-2">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Share your hot take on this season's best fight or villain..."
                      className="flex-1 rounded-full border border-zinc-200 bg-zinc-50 px-4 py-2.5 text-sm text-zinc-900 placeholder:text-zinc-400 focus:border-rose-500 focus:bg-white focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="inline-flex items-center gap-1.5 rounded-full bg-rose-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-rose-700 cursor-pointer"
                    >
                      <Send className="h-3.5 w-3.5" />
                      <span>Post</span>
                    </button>
                  </form>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};
