import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles } from 'lucide-react';
import { CelReveal } from './MotionPrimitives';

interface CtaSectionProps {
  onClaimHandle: (handle: string) => void;
}

export const CtaSection: React.FC<CtaSectionProps> = ({ onClaimHandle }) => {
  const [handleInput, setHandleInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onClaimHandle(handleInput.trim() || 'otaku_senpai');
  };

  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <CelReveal>
          <div className="relative overflow-hidden rounded-[32px] bg-zinc-950 px-6 py-16 text-center text-white shadow-2xl sm:px-14 sm:py-24">
            {/* Subtle Dark Dot Matrix + Soft Vermilion Atmospheric Glow */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-dot-grid-dark [mask-image:radial-gradient(ellipse_75%_65%_at_50%_50%,#000_55%,transparent_100%)]"
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-28 left-1/2 -translate-x-1/2 h-80 w-[620px] rounded-full bg-gradient-to-r from-rose-600/35 via-orange-500/25 to-indigo-500/30 blur-3xl animate-pulse-soft"
            />

            <div className="relative z-10 mx-auto max-w-2xl">
              <div className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-3.5 py-1 text-xs font-semibold text-rose-300 backdrop-blur-md">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Free Forever · Instant Discord & Web Embeds</span>
              </div>

              <h2 className="mt-6 text-3xl font-extrabold tracking-[-0.035em] text-white sm:text-5xl">
                Claim your handle before next week’s episode drops.
              </h2>

              <p className="mt-4 text-base leading-relaxed text-zinc-400 sm:text-lg">
                Join 184,000+ anime fans sharing 24fps sakuga cuts, debating iconic
                enemy showdowns, and hosting spoiler-safe watch parties.
              </p>

              {/* Interactive Handle Claim Bar */}
              <form
                onSubmit={handleSubmit}
                className="mx-auto mt-9 flex max-w-md flex-col gap-3 sm:flex-row sm:items-center sm:rounded-full sm:border sm:border-white/15 sm:bg-white/10 sm:p-1.5 sm:backdrop-blur-md"
              >
                <div className="flex flex-1 items-center rounded-full border border-white/15 bg-white/10 px-4 py-3 sm:border-0 sm:bg-transparent sm:py-2">
                  <span className="font-mono text-xs text-zinc-400 select-none">
                    animefang.gg/@
                  </span>
                  <input
                    type="text"
                    value={handleInput}
                    onChange={(e) =>
                      setHandleInput(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))
                    }
                    placeholder="yourhandle"
                    aria-label="Claim your community handle"
                    className="ml-0.5 w-full bg-transparent text-sm font-semibold text-white placeholder:text-zinc-500 focus:outline-none"
                  />
                </div>

                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-full bg-rose-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-rose-600/30 transition hover:bg-rose-500 cursor-pointer"
                >
                  <span>Claim Handle</span>
                  <ArrowRight className="h-4 w-4" />
                </motion.button>
              </form>

              <p className="mt-4 text-xs text-zinc-500">
                No credit card required · Set up episode spoiler protection in 15 seconds.
              </p>
            </div>
          </div>
        </CelReveal>
      </div>
    </section>
  );
};
