import React from 'react';
import { Star } from 'lucide-react';
import { TESTIMONIALS } from '../data/animeContent';
import {
  CelReveal,
  SakugaStagger,
  SakugaItem,
  SpotlightCard,
} from './MotionPrimitives';

export const TestimonialsSection: React.FC = () => {
  return (
    <section
      id="testimonials"
      className="border-t border-zinc-200/80 bg-zinc-50/70 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <CelReveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-bold tracking-[0.14em] text-rose-600 uppercase">
            Loved by the Fandom
          </span>
          <h2 className="mt-3 text-3xl font-extrabold tracking-[-0.035em] text-zinc-950 sm:text-5xl">
            Trusted by clippers, guild hosts & sakuga nerds.
          </h2>
          <p className="mt-4 text-base text-zinc-600 sm:text-lg">
            Hear how creators and community leaders run weekly watch rooms and share
            unforgettable anime moments without friction.
          </p>
        </CelReveal>

        <SakugaStagger className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {TESTIMONIALS.map((item) => (
            <SakugaItem key={item.author}>
              <SpotlightCard className="h-full p-7 sm:p-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-0.5 text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-amber-400" />
                      ))}
                    </div>
                    <span className="rounded-full bg-zinc-100 px-2.5 py-1 font-mono text-[11px] font-semibold text-zinc-600">
                      {item.metric}
                    </span>
                  </div>

                  <blockquote className="mt-5 text-sm leading-7 text-zinc-700 sm:text-[15px]">
                    “{item.quote}”
                  </blockquote>
                </div>

                <div className="mt-7 flex items-center gap-3.5 border-t border-zinc-100 pt-5">
                  <img
                    src={item.avatar}
                    alt={item.author}
                    className="h-11 w-11 rounded-full object-cover ring-2 ring-rose-100"
                  />
                  <div>
                    <p className="text-sm font-bold text-zinc-950">{item.author}</p>
                    <p className="text-xs text-zinc-500">{item.role}</p>
                  </div>
                </div>
              </SpotlightCard>
            </SakugaItem>
          ))}
        </SakugaStagger>
      </div>
    </section>
  );
};
