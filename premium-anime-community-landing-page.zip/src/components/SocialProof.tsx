import React from 'react';
import { CelReveal, SakugaStagger, SakugaItem } from './MotionPrimitives';

const GUILD_LOGOS = [
  { name: 'SAKUGA ARCHIVE', tag: '48K MEMBERS' },
  { name: 'SHIBUYA WATCH', tag: 'SIMULCAST CLUB' },
  { name: 'KAIJU CODEX', tag: 'BOSS LORE' },
  { name: 'RONIN AMV LABS', tag: 'EDITORS GUILD' },
  { name: 'MECHA FOUNDRY', tag: 'KEYFRAMES' },
  { name: 'CRIMSON PANEL', tag: 'MANGA SYNC' },
];

export const SocialProof: React.FC = () => {
  return (
    <section className="border-y border-zinc-200/75 bg-white py-12 sm:py-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <CelReveal className="text-center">
          <p className="text-xs font-bold tracking-[0.14em] text-zinc-400 uppercase">
            Powering seasonal watch parties, sakuga vaults & enemy rankings across 950+ anime guilds
          </p>
        </CelReveal>

        <SakugaStagger
          staggerDelay={0.05}
          className="mt-8 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-6 items-center"
        >
          {GUILD_LOGOS.map((guild) => (
            <SakugaItem key={guild.name}>
              <div className="group flex flex-col items-center justify-center rounded-xl px-3 py-2 text-center transition-colors hover:bg-zinc-50">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rotate-45 bg-zinc-300 transition-colors duration-200 group-hover:bg-rose-600" />
                  <span className="text-sm font-extrabold tracking-[-0.02em] text-zinc-700 transition-colors duration-200 group-hover:text-zinc-950">
                    {guild.name}
                  </span>
                </div>
                <span className="mt-0.5 font-mono text-[10px] font-medium tracking-wider text-zinc-400">
                  {guild.tag}
                </span>
              </div>
            </SakugaItem>
          ))}
        </SakugaStagger>
      </div>
    </section>
  );
};
