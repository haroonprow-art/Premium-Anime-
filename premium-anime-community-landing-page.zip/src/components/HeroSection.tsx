import React, { useRef, useState } from 'react';
import {
  motion,
  AnimatePresence,
  useScroll,
  useTransform,
} from 'framer-motion';
import {
  ArrowRight,
  Play,
  Pause,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Sparkles,
  Flame,
  Swords,
  Crown,
  Share2,
  Check,
} from 'lucide-react';
import { SAKUGA_EASE } from './MotionPrimitives';

interface HeroSectionProps {
  onOpenModal: (mode: 'join' | 'share') => void;
}

interface FloatingReaction {
  id: number;
  label: string;
  xPercent: number;
}

const HERO_SCENES = [
  {
    id: 'rooftop',
    badge: 'RIVAL CLASH · S2 EP 23',
    title: 'Blade of the Vermilion Horizon — Rain Parry Cut #084',
    animator: 'Key Animation: Y. Nakamura Homage',
    image: '/images/showcase-hero-sakuga.jpg',
    baseFrame: 148,
    fps: '24 FPS · 10-BIT HDR',
  },
  {
    id: 'mecha',
    badge: 'ENEMY BOSS REVEAL · ACT III',
    title: 'Unit-09 "Calamity" — Neo-Bay Seawall Breach',
    animator: 'Composite: Studio Mech Unit',
    image: '/images/clip-mecha-boss.jpg',
    baseFrame: 412,
    fps: '60 FPS · LOSSLESS AUDIO',
  },
];

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenModal }) => {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: stageRef,
    offset: ['start end', 'center center'],
  });
  const stageScale = useTransform(scrollYProgress, [0, 1], [0.97, 1]);
  const stageY = useTransform(scrollYProgress, [0, 1], [24, 0]);

  const [sceneIdx, setSceneIdx] = useState(0);
  const [frameOffset, setFrameOffset] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);
  const [reactions, setReactions] = useState([
    { key: 'clash', label: 'Rival Clash', count: 1428, icon: Swords },
    { key: 'sakuga', label: 'Peak Sakuga', count: 2894, icon: Flame },
    { key: 'boss', label: 'S+ Enemy', count: 964, icon: Crown },
  ]);
  const [floatingBursts, setFloatingBursts] = useState<FloatingReaction[]>([]);

  const activeScene = HERO_SCENES[sceneIdx];
  const currentFrameNumber = activeScene.baseFrame + frameOffset;

  const triggerReaction = (key: string, label: string) => {
    setReactions((prev) =>
      prev.map((item) =>
        item.key === key ? { ...item, count: item.count + 1 } : item
      )
    );
    const id = Date.now() + Math.random();
    const xPercent = 22 + Math.floor(Math.random() * 56);
    setFloatingBursts((prev) => [...prev.slice(-5), { id, label, xPercent }]);
    setTimeout(() => {
      setFloatingBursts((prev) => prev.filter((b) => b.id !== id));
    }, 1500);
  };

  const handleCopyShare = () => {
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <section className="relative overflow-hidden pt-12 pb-20 sm:pt-16 sm:pb-28 lg:pt-20">
      {/* Subtle Ambient Dot Matrix & Soft Atmospheric Glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-dot-grid [mask-image:radial-gradient(ellipse_75%_60%_at_50%_28%,#000_55%,transparent_100%)]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-[480px] w-[860px] rounded-full bg-gradient-to-tr from-rose-200/45 via-orange-100/35 to-indigo-200/35 blur-3xl animate-float-slow"
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Centered Editorial Hero Copy */}
        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: SAKUGA_EASE }}
            className="inline-flex items-center gap-2 rounded-full border border-rose-200/80 bg-white/90 px-3.5 py-1.5 text-xs font-semibold text-zinc-800 shadow-2xs backdrop-blur-md"
          >
            <span className="flex h-2 w-2 rounded-full bg-rose-600 ring-4 ring-rose-500/20" />
            <span>Spring Simulcast Hub · 184,000+ Anime Fans Active Now</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.08, ease: SAKUGA_EASE }}
            className="mt-6 text-4xl font-extrabold tracking-[-0.038em] text-zinc-950 sm:text-6xl lg:text-[66px] lg:leading-[1.04]"
          >
            Where anime fans unite, debate &{' '}
            <span className="bg-gradient-to-r from-rose-600 via-rose-500 to-orange-500 bg-clip-text text-transparent">
              share iconic cuts.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.16, ease: SAKUGA_EASE }}
            className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-zinc-600 sm:text-lg sm:leading-8"
          >
            Drop lossless 24fps sakuga clips, rank legendary anime enemies and rival
            clashes, and rally your guild in automatic spoiler-shielded episode rooms.
          </motion.p>

          {/* Primary & Secondary CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.24, ease: SAKUGA_EASE }}
            className="mt-8 flex flex-col items-center justify-center gap-3.5 sm:flex-row"
          >
            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onOpenModal('join')}
              className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-full bg-rose-600 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-rose-600/25 transition-colors hover:bg-rose-700 cursor-pointer"
            >
              <span>Join the Community Free</span>
              <ArrowRight className="h-4 w-4" />
            </motion.button>

            <a
              href="#showcase"
              className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-full border border-zinc-200 bg-white px-7 py-3.5 text-sm font-semibold text-zinc-900 shadow-2xs transition-all duration-200 hover:border-zinc-300 hover:bg-zinc-50"
            >
              <Sparkles className="h-4 w-4 text-rose-600" />
              <span>Explore Live Feed & Codex</span>
            </a>
          </motion.div>

          {/* Compact Trust Strip */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.34 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-xs font-medium text-zinc-500"
          >
            <div className="flex items-center gap-2.5">
              <div className="flex -space-x-2">
                <img
                  src="/images/avatar-kenji.jpg"
                  alt="Kenji"
                  className="h-7 w-7 rounded-full object-cover ring-2 ring-white"
                />
                <img
                  src="/images/avatar-haruka.jpg"
                  alt="Haruka"
                  className="h-7 w-7 rounded-full object-cover ring-2 ring-white"
                />
                <img
                  src="/images/avatar-ren.jpg"
                  alt="Ren"
                  className="h-7 w-7 rounded-full object-cover ring-2 ring-white"
                />
              </div>
              <span className="text-zinc-700 font-semibold">4.9/5</span>
              <span>from 12,400+ clippers & watch guilds</span>
            </div>
            <span className="hidden sm:inline text-zinc-300">•</span>
            <div className="inline-flex items-center gap-1.5 text-zinc-600">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              <span>100% Spoiler-Shielded Threads</span>
            </div>
          </motion.div>
        </div>

        {/* Interactive Product Window Stage */}
        <motion.div
          ref={stageRef}
          style={{ scale: stageScale, y: stageY }}
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, delay: 0.28, ease: SAKUGA_EASE }}
          className="mx-auto mt-14 max-w-5xl"
        >
          <div className="overflow-hidden rounded-3xl border border-zinc-200/90 bg-white/95 p-2 shadow-[0_24px_70px_-16px_rgba(9,9,11,0.12)] backdrop-blur-xl sm:p-3">
            {/* Window Top Chrome */}
            <div className="flex flex-wrap items-center justify-between gap-3 px-3 py-2.5 sm:px-4">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-zinc-200" />
                <span className="h-2.5 w-2.5 rounded-full bg-zinc-200" />
                <span className="h-2.5 w-2.5 rounded-full bg-zinc-200" />
                <span className="ml-2 font-mono text-xs font-medium text-zinc-400">
                  animefang.gg/cuts/featured
                </span>
              </div>

              {/* Scene Switcher Pills */}
              <div className="flex items-center gap-1.5 rounded-full bg-zinc-100 p-1">
                {HERO_SCENES.map((scene, idx) => (
                  <button
                    key={scene.id}
                    type="button"
                    onClick={() => {
                      setSceneIdx(idx);
                      setFrameOffset(0);
                    }}
                    className={`rounded-full px-3 py-1 text-xs font-semibold transition-all cursor-pointer ${
                      sceneIdx === idx
                        ? 'bg-white text-zinc-950 shadow-2xs'
                        : 'text-zinc-500 hover:text-zinc-900'
                    }`}
                  >
                    {idx === 0 ? 'Rival Clash Cut' : 'Enemy Boss Reveal'}
                  </button>
                ))}
              </div>
            </div>

            {/* Widescreen Interactive Sakuga Viewport */}
            <div className="relative overflow-hidden rounded-2xl bg-zinc-950 aspect-[16/9]">
              <AnimatePresence mode="wait">
                <motion.img
                  key={`${activeScene.id}-${frameOffset}`}
                  src={activeScene.image}
                  alt={activeScene.title}
                  initial={{ opacity: 0.84, scale: 1.015 }}
                  animate={{
                    opacity: 1,
                    scale: isPlaying ? 1.03 : 1.0,
                  }}
                  exit={{ opacity: 0.85 }}
                  transition={{ duration: 0.35, ease: SAKUGA_EASE }}
                  className="h-full w-full object-cover"
                />
              </AnimatePresence>

              {/* Subtle Top & Bottom Scrim for Crisp Telemetry Readability */}
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-black/45" />

              {/* Top HUD Metadata */}
              <div className="absolute top-3.5 left-3.5 right-3.5 flex flex-wrap items-center justify-between gap-2 sm:top-5 sm:left-5 sm:right-5">
                <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-black/55 px-3 py-1 text-[11px] font-semibold tracking-wide text-white backdrop-blur-md">
                  <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse" />
                  <span>{activeScene.badge}</span>
                </div>

                <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-black/55 px-3 py-1 font-mono text-[11px] text-zinc-200 backdrop-blur-md">
                  <span>FRM #{String(currentFrameNumber).padStart(4, '0')}</span>
                  <span className="text-white/30">|</span>
                  <span className="text-emerald-400">{activeScene.fps}</span>
                </div>
              </div>

              {/* Floating Live Reaction Bursts */}
              <AnimatePresence>
                {floatingBursts.map((burst) => (
                  <motion.div
                    key={burst.id}
                    initial={{ opacity: 0, y: 12, scale: 0.8 }}
                    animate={{ opacity: 1, y: -74, scale: 1.05 }}
                    exit={{ opacity: 0, y: -115, scale: 0.9 }}
                    transition={{ duration: 1.25, ease: 'easeOut' }}
                    style={{ left: `${burst.xPercent}%` }}
                    className="pointer-events-none absolute bottom-20 z-20 -translate-x-1/2 rounded-full border border-white/25 bg-rose-600/90 px-3 py-1 text-xs font-bold text-white shadow-lg backdrop-blur-md"
                  >
                    +1 {burst.label}
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Bottom Interactive Frame Controls & Live Reactions */}
              <div className="absolute bottom-3.5 left-3.5 right-3.5 flex flex-col gap-3 sm:bottom-5 sm:left-5 sm:right-5">
                <div className="flex flex-wrap items-end justify-between gap-3">
                  <div>
                    <p className="text-xs font-medium text-rose-300">
                      {activeScene.animator}
                    </p>
                    <h2 className="text-base font-bold text-white sm:text-xl">
                      {activeScene.title}
                    </h2>
                  </div>

                  {/* Interactive Frame Stepper */}
                  <div className="flex items-center gap-1.5 rounded-full border border-white/15 bg-black/65 p-1 backdrop-blur-md">
                    <button
                      type="button"
                      onClick={() => setIsPlaying((p) => !p)}
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-zinc-950 transition hover:bg-rose-500 hover:text-white cursor-pointer"
                      aria-label={isPlaying ? 'Pause' : 'Play'}
                    >
                      {isPlaying ? (
                        <Pause className="h-3.5 w-3.5" />
                      ) : (
                        <Play className="h-3.5 w-3.5 translate-x-0.5" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsPlaying(false);
                        setFrameOffset((f) => f - 1);
                      }}
                      className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium text-zinc-200 hover:bg-white/10 cursor-pointer"
                      title="Step back 1 frame"
                    >
                      <ChevronLeft className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">-1 Frame</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsPlaying(false);
                        setFrameOffset((f) => f + 1);
                      }}
                      className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium text-zinc-200 hover:bg-white/10 cursor-pointer"
                      title="Step forward 1 frame"
                    >
                      <span className="hidden sm:inline">+1 Frame</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Reaction Bar Below Viewport */}
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-3 px-2 py-1.5 sm:px-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold text-zinc-500 mr-1">
                  Tap to stamp frame:
                </span>
                {reactions.map((item) => {
                  const IconComponent = item.icon;
                  return (
                    <motion.button
                      key={item.key}
                      type="button"
                      whileTap={{ scale: 0.93 }}
                      onClick={() => triggerReaction(item.key, item.label)}
                      className="inline-flex items-center gap-1.5 rounded-full border border-zinc-200 bg-zinc-50/90 px-3 py-1.5 text-xs font-semibold text-zinc-800 transition-colors hover:border-rose-300 hover:bg-rose-50 hover:text-rose-700 cursor-pointer"
                    >
                      <IconComponent className="h-3.5 w-3.5 text-rose-600" />
                      <span>{item.label}</span>
                      <span className="ml-0.5 font-mono text-[11px] text-zinc-500">
                        {item.count.toLocaleString()}
                      </span>
                    </motion.button>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={handleCopyShare}
                className="inline-flex items-center gap-1.5 rounded-full border border-zinc-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-zinc-700 transition hover:border-zinc-300 hover:text-zinc-950 cursor-pointer"
              >
                {copiedLink ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                    <span className="text-emerald-700">Embed Link Copied!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="h-3.5 w-3.5 text-zinc-500" />
                    <span>Copy Clean Discord Embed</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
