import React, { useEffect, useRef, useState } from 'react';
import {
  motion,
  useInView,
  useMotionTemplate,
  useMotionValue,
  animate,
  type HTMLMotionProps,
} from 'framer-motion';

export const SAKUGA_EASE = [0.22, 1, 0.36, 1] as const;

interface CelRevealProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode;
  delay?: number;
  yOffset?: number;
  className?: string;
}

export const CelReveal: React.FC<CelRevealProps> = ({
  children,
  delay = 0,
  yOffset = 20,
  className = '',
  ...props
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: yOffset }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55, delay, ease: SAKUGA_EASE }}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  );
};

interface SakugaStaggerProps {
  children: React.ReactNode;
  className?: string;
  staggerDelay?: number;
}

export const SakugaStagger: React.FC<SakugaStaggerProps> = ({
  children,
  className = '',
  staggerDelay = 0.07,
}) => {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-60px' }}
      variants={{
        hidden: {},
        visible: {
          transition: {
            staggerChildren: staggerDelay,
          },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

export const SakugaItem: React.FC<{
  children: React.ReactNode;
  className?: string;
}> = ({ children, className = '' }) => {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 18 },
        visible: {
          opacity: 1,
          y: 0,
          transition: { duration: 0.5, ease: SAKUGA_EASE },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

interface SpotlightCardProps {
  children: React.ReactNode;
  className?: string;
  spotlightColor?: string;
}

export const SpotlightCard: React.FC<SpotlightCardProps> = ({
  children,
  className = '',
  spotlightColor = 'rgba(225, 29, 72, 0.065)',
}) => {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  function handleMouseMove({
    currentTarget,
    clientX,
    clientY,
  }: React.MouseEvent<HTMLDivElement>) {
    const { left, top } = currentTarget.getBoundingClientRect();
    mouseX.set(clientX - left);
    mouseY.set(clientY - top);
  }

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      whileHover={{ y: -3 }}
      transition={{ duration: 0.24, ease: SAKUGA_EASE }}
      className={`group relative overflow-hidden rounded-2xl border border-zinc-200/85 bg-white shadow-[0_1px_2px_rgba(9,9,11,0.03)] transition-shadow duration-300 hover:shadow-[0_12px_32px_-8px_rgba(9,9,11,0.08)] ${className}`}
    >
      <motion.div
        className="pointer-events-none absolute -inset-px rounded-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{
          background: useMotionTemplate`radial-gradient(420px circle at ${mouseX}px ${mouseY}px, ${spotlightColor}, transparent 80%)`,
        }}
      />
      <div className="relative z-10 h-full">{children}</div>
    </motion.div>
  );
};

interface AnimatedCounterProps {
  target: number;
  suffix?: string;
  prefix?: string;
  decimals?: number;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  target,
  suffix = '',
  prefix = '',
  decimals = 0,
}) => {
  const ref = useRef<HTMLSpanElement | null>(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });
  const [displayValue, setDisplayValue] = useState<string>(
    `${prefix}${target.toFixed(decimals)}${suffix}`
  );

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, target, {
      duration: 1.3,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (latest) => {
        const formatted =
          decimals > 0
            ? latest.toFixed(decimals)
            : Math.round(latest).toLocaleString();
        setDisplayValue(`${prefix}${formatted}${suffix}`);
      },
    });
    return () => controls.stop();
  }, [inView, target, suffix, prefix, decimals]);

  return <span ref={ref}>{displayValue}</span>;
};

export const BrandLogo: React.FC<{ darkText?: boolean; size?: 'sm' | 'md' }> = ({
  darkText = true,
  size = 'md',
}) => {
  const boxSize = size === 'sm' ? 'h-7 w-7' : 'h-8 w-8';
  return (
    <div className="inline-flex items-center gap-2.5 select-none">
      <div
        className={`${boxSize} relative flex items-center justify-center rounded-xl bg-gradient-to-br from-rose-600 via-rose-500 to-orange-500 text-white shadow-sm shadow-rose-500/25`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          className="h-4.5 w-4.5"
          aria-hidden="true"
        >
          {/* Crisp geometric katana-fang mark */}
          <path
            d="M4.5 5.5L19.5 4L14.2 19.8L10.8 13.2L4.5 5.5Z"
            fill="currentColor"
          />
          <path
            d="M10.8 13.2L19.5 4"
            stroke="rgba(255,255,255,0.45)"
            strokeWidth="1.4"
            strokeLinecap="round"
          />
        </svg>
      </div>
      <span
        className={`text-[17px] font-extrabold tracking-[-0.03em] ${
          darkText ? 'text-zinc-950' : 'text-white'
        }`}
      >
        Anime<span className="text-rose-600">Fang</span>
      </span>
    </div>
  );
};
