import React, { useState } from 'react';
import {
  Film,
  Swords,
  EyeOff,
  Eye,
  Radio,
  Columns2,
  Sparkles,
} from 'lucide-react';
import {
  CelReveal,
  SakugaStagger,
  SakugaItem,
  SpotlightCard,
} from './MotionPrimitives';

export const FeaturesSection: React.FC = () => {
  const [selectedFrame, setSelectedFrame] = useState(2);
  const [spoilerRevealed, setSpoilerRevealed] = useState(false);
  const [compareMode, setCompareMode] = useState<'anime' | 'manga'>('anime');
  const [selectedTier, setSelectedTier] = useState<'S+' | 'SS' | 'S'>('S+');

  const frameTimeline = [
    { frame: '081', note: ' anticipation crouch' },
    { frame: '083', note: 'katana draw flash' },
    { frame: '084', note: 'impact black-white frame' },
    { frame: '087', note: 'rain shockwave ring' },
    { frame: '092', note: 'landing follow-through' },
  ];

  const tierDetails: Record<'S+' | 'SS' | 'S', { title: string; winRate: string; ep: string }> = {
    'S+': {
      title: 'Unit-09 "Calamity" · Seawall Boss',
      winRate: '94.2% Community Menace Score',
      ep: 'Peak Entrance: Act III · 54:10',
    },
    SS: {
      title: 'Kagura of the Hollow Shrine',
      winRate: '91.0% Community Menace Score',
      ep: 'Domain Reveal: S1 · EP 12',
    },
    S: {
      title: 'Rei "Crimson Fang" Kurosawa',
      winRate: '88.6% Community Rival Score',
      ep: 'Rooftop Clash: S2 · EP 23',
    },
  };

  return (
    <section id="features" className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <CelReveal className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-1.5 rounded-full border border-rose-200 bg-rose-50/70 px-3 py-1 text-xs font-bold tracking-wide text-rose-700 uppercase">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Engineered for Fandom Craft</span>
          </div>
          <h2 className="mt-4 text-3xl font-extrabold tracking-[-0.035em] text-zinc-950 sm:text-5xl">
            Every tool anime fans wished social platforms built.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-zinc-600 sm:text-lg">
            No more crushed dark scenes, untagged finale spoilers, or buried discussions.
            Share high-bitrate clips, catalog iconic enemies, and celebrate every frame together.
          </p>
        </CelReveal>

        {/* Bento Grid */}
        <SakugaStagger className="mt-16 grid grid-cols-1 gap-5 md:grid-cols-6">
          {/* Card 1: 3 Cols — Frame-Accurate Sakuga Sharing */}
          <SakugaItem className="md:col-span-3">
            <SpotlightCard className="h-full p-7 sm:p-8 flex flex-col justify-between">
              <div>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-rose-50 text-rose-600 border border-rose-100">
                  <Film className="h-5 w-5" />
                </div>
                <h3 className="mt-5 text-xl font-bold tracking-[-0.02em] text-zinc-950">
                  Native 24fps Sakuga & Clip Studio
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                  Scrub on-ones animation frame by frame, tag key animators, and share lossless
                  10-bit HDR clips without muddy social video compression.
                </p>
              </div>

              {/* Interactive Frame Timeline Widget */}
              <div className="mt-7 rounded-xl border border-zinc-200/80 bg-zinc-50/90 p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono font-semibold text-zinc-900">
                    CUT #{frameTimeline[selectedFrame].frame}
                  </span>
                  <span className="font-medium text-rose-600">
                    {frameTimeline[selectedFrame].note}
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-5 gap-1.5">
                  {frameTimeline.map((item, idx) => (
                    <button
                      key={item.frame}
                      type="button"
                      onClick={() => setSelectedFrame(idx)}
                      className={`rounded-lg py-2 font-mono text-xs font-semibold transition-all cursor-pointer ${
                        selectedFrame === idx
                          ? 'bg-rose-600 text-white shadow-xs'
                          : 'bg-white text-zinc-600 border border-zinc-200 hover:border-zinc-300'
                      }`}
                    >
                      :{item.frame}
                    </button>
                  ))}
                </div>
              </div>
            </SpotlightCard>
          </SakugaItem>

          {/* Card 2: 3 Cols — Enemy & Rival Codex */}
          <SakugaItem className="md:col-span-3">
            <SpotlightCard className="h-full p-7 sm:p-8 flex flex-col justify-between">
              <div>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-zinc-950 text-white">
                  <Swords className="h-5 w-5 text-rose-400" />
                </div>
                <h3 className="mt-5 text-xl font-bold tracking-[-0.02em] text-zinc-950">
                  Community Enemy & Rival Codex
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                  Share iconic villain entrances, rank final-boss phases, and link boss fight
                  clips directly to structured series threat tiers voted on by fans.
                </p>
              </div>

              {/* Interactive Threat Tier Switcher */}
              <div className="mt-7 rounded-xl border border-zinc-200/80 bg-zinc-50/90 p-4">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-zinc-500">
                    Inspect Threat Tier:
                  </span>
                  <div className="flex gap-1.5">
                    {(['S+', 'SS', 'S'] as const).map((tier) => (
                      <button
                        key={tier}
                        type="button"
                        onClick={() => setSelectedTier(tier)}
                        className={`rounded-md px-2.5 py-1 font-mono text-xs font-bold transition cursor-pointer ${
                          selectedTier === tier
                            ? 'bg-zinc-950 text-rose-400'
                            : 'bg-white text-zinc-600 border border-zinc-200 hover:bg-zinc-100'
                        }`}
                      >
                        {tier} TIER
                      </button>
                    ))}
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between rounded-lg bg-white p-3 border border-zinc-200/75">
                  <div>
                    <p className="text-xs font-bold text-zinc-950">
                      {tierDetails[selectedTier].title}
                    </p>
                    <p className="mt-0.5 text-[11px] text-zinc-500">
                      {tierDetails[selectedTier].ep}
                    </p>
                  </div>
                  <span className="rounded-full bg-rose-50 px-2.5 py-1 font-mono text-[11px] font-semibold text-rose-700">
                    {tierDetails[selectedTier].winRate.split(' ')[0]}
                  </span>
                </div>
              </div>
            </SpotlightCard>
          </SakugaItem>

          {/* Card 3: 2 Cols — Interactive Spoiler Shield */}
          <SakugaItem className="md:col-span-2">
            <SpotlightCard className="h-full p-7 flex flex-col justify-between">
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100">
                  {spoilerRevealed ? (
                    <Eye className="h-5 w-5" />
                  ) : (
                    <EyeOff className="h-5 w-5" />
                  )}
                </div>
                <h3 className="mt-4 text-lg font-bold tracking-[-0.02em] text-zinc-950">
                  Episode-Aware Spoiler Shields
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                  Sync your episode progress once. Any boss twist beyond your current episode stays
                  cleanly frosted until you tap reveal.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSpoilerRevealed((prev) => !prev)}
                className="mt-6 relative w-full overflow-hidden rounded-xl border border-zinc-200 bg-zinc-950 p-3.5 text-left transition cursor-pointer"
              >
                <div
                  className={`transition-all duration-300 ${
                    spoilerRevealed ? 'blur-none opacity-100' : 'blur-md opacity-45 select-none'
                  }`}
                >
                  <span className="font-mono text-[10px] text-rose-400 uppercase">
                    S2 · EP 23 PLOT TWIST
                  </span>
                  <p className="mt-0.5 text-xs font-medium text-white">
                    The masked Sovereign unseals the second crimson blade at 19:42!
                  </p>
                </div>
                {!spoilerRevealed && (
                  <div className="absolute inset-0 flex items-center justify-center bg-zinc-950/40">
                    <span className="rounded-full bg-white px-3 py-1 text-[11px] font-bold text-zinc-950 shadow-sm">
                      Tap to Test Spoiler Reveal
                    </span>
                  </div>
                )}
              </button>
            </SpotlightCard>
          </SakugaItem>

          {/* Card 4: 2 Cols — Live Simulcast Watch Rooms */}
          <SakugaItem className="md:col-span-2">
            <SpotlightCard className="h-full p-7 flex flex-col justify-between">
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-600 border border-amber-100">
                  <Radio className="h-5 w-5" />
                </div>
                <h3 className="mt-4 text-lg font-bold tracking-[-0.02em] text-zinc-950">
                  Simulcast Watch Lounges
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                  Count down to weekly Japanese broadcast drops with live reaction heatmaps synced
                  to exact episode timestamps.
                </p>
              </div>

              <div className="mt-6 rounded-xl border border-zinc-200/80 bg-zinc-50 p-3.5">
                <div className="flex items-center justify-between text-[11px] font-mono text-zinc-500">
                  <span className="flex items-center gap-1.5 text-emerald-700 font-semibold">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
                    2,410 watching EP 12
                  </span>
                  <span>19:42</span>
                </div>
                <div className="mt-2.5 flex items-end gap-1 h-10">
                  {[28, 42, 35, 64, 95, 100, 78, 52, 68, 84, 60, 44].map((bar, i) => (
                    <div
                      key={i}
                      style={{ height: `${bar}%` }}
                      className={`flex-1 rounded-t-sm transition-all ${
                        bar > 80 ? 'bg-rose-500' : 'bg-zinc-300'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </SpotlightCard>
          </SakugaItem>

          {/* Card 5: 2 Cols — Manga vs Anime Side-by-Side */}
          <SakugaItem className="md:col-span-2">
            <SpotlightCard className="h-full p-7 flex flex-col justify-between">
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-100">
                  <Columns2 className="h-5 w-5" />
                </div>
                <h3 className="mt-4 text-lg font-bold tracking-[-0.02em] text-zinc-950">
                  Manga-to-Anime Sync
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                  Pair source manga chapters with adapted studio frames so fans appreciate how iconic
                  panels leap into motion.
                </p>
              </div>

              <div className="mt-6 rounded-xl border border-zinc-200/80 bg-zinc-50 p-3">
                <div className="grid grid-cols-2 gap-1 rounded-lg bg-zinc-200/70 p-0.5 text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setCompareMode('anime')}
                    className={`rounded-md py-1.5 transition cursor-pointer ${
                      compareMode === 'anime'
                        ? 'bg-white text-zinc-950 shadow-2xs'
                        : 'text-zinc-600'
                    }`}
                  >
                    Studio Frame
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompareMode('manga')}
                    className={`rounded-md py-1.5 transition cursor-pointer ${
                      compareMode === 'manga'
                        ? 'bg-white text-zinc-950 shadow-2xs'
                        : 'text-zinc-600'
                    }`}
                  >
                    Ch. 114 Ink
                  </button>
                </div>
                <div className="mt-2.5 overflow-hidden rounded-lg relative h-14">
                  <img
                    src="/images/clip-spirit-shrine.jpg"
                    alt="Panel comparison preview"
                    className={`h-full w-full object-cover transition-all duration-300 ${
                      compareMode === 'manga'
                        ? 'grayscale contrast-150 brightness-110'
                        : ''
                    }`}
                  />
                  <span className="absolute bottom-1.5 right-2 rounded bg-black/70 px-1.5 py-0.5 font-mono text-[10px] text-white">
                    {compareMode === 'manga' ? 'INK SPREAD P.18' : 'EP.12 COLOR PASS'}
                  </span>
                </div>
              </div>
            </SpotlightCard>
          </SakugaItem>
        </SakugaStagger>
      </div>
    </section>
  );
};
