import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Sparkles } from 'lucide-react';
import { PRICING_TIERS } from '../data/animeContent';
import { CelReveal, SakugaStagger, SakugaItem } from './MotionPrimitives';

interface PricingSectionProps {
  onSelectPlan: (planName: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({
  onSelectPlan,
}) => {
  const [annual, setAnnual] = useState(true);

  return (
    <section
      id="pricing"
      className="border-t border-zinc-200/80 bg-white py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <CelReveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-bold tracking-[0.14em] text-rose-600 uppercase">
            Simple, Fan-First Membership
          </span>
          <h2 className="mt-3 text-3xl font-extrabold tracking-[-0.035em] text-zinc-950 sm:text-5xl">
            Free forever for fans. Pro power for creators & guilds.
          </h2>
          <p className="mt-4 text-base text-zinc-600 sm:text-lg">
            Zero paywalls on community discussions, episode threads, or Enemy Codex rankings.
            Upgrade anytime for 4K lossless uploads and large private rooms.
          </p>

          {/* Interactive Billing Cycle Switcher */}
          <div className="mt-8 inline-flex items-center gap-1 rounded-full border border-zinc-200 bg-zinc-100/90 p-1">
            <button
              type="button"
              onClick={() => setAnnual(false)}
              className={`relative rounded-full px-5 py-2 text-xs font-bold transition cursor-pointer ${
                !annual ? 'text-zinc-950' : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              {!annual && (
                <motion.span
                  layoutId="billingToggle"
                  transition={{ type: 'spring', bounce: 0.18, duration: 0.4 }}
                  className="absolute inset-0 rounded-full bg-white shadow-2xs"
                />
              )}
              <span className="relative z-10">Monthly</span>
            </button>

            <button
              type="button"
              onClick={() => setAnnual(true)}
              className={`relative inline-flex items-center gap-2 rounded-full px-5 py-2 text-xs font-bold transition cursor-pointer ${
                annual ? 'text-zinc-950' : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              {annual && (
                <motion.span
                  layoutId="billingToggle"
                  transition={{ type: 'spring', bounce: 0.18, duration: 0.4 }}
                  className="absolute inset-0 rounded-full bg-white shadow-2xs"
                />
              )}
              <span className="relative z-10">Yearly</span>
              <span className="relative z-10 rounded-full bg-rose-100 px-2 py-0.5 text-[10px] font-extrabold text-rose-700">
                SAVE 25%
              </span>
            </button>
          </div>
        </CelReveal>

        {/* Pricing Cards */}
        <SakugaStagger className="mt-14 grid grid-cols-1 gap-6 lg:grid-cols-3 items-stretch">
          {PRICING_TIERS.map((tier) => {
            const displayPrice = annual ? tier.yearlyPrice : tier.monthlyPrice;
            const isPro = tier.highlighted;

            return (
              <SakugaItem key={tier.id} className="h-full">
                <div
                  className={`relative flex h-full flex-col justify-between rounded-3xl p-8 transition-all duration-300 ${
                    isPro
                      ? 'border-2 border-rose-500 bg-zinc-950 text-white shadow-2xl shadow-rose-600/15 lg:-translate-y-2'
                      : 'border border-zinc-200 bg-[#FAFAFA] text-zinc-950 hover:border-zinc-300 hover:bg-white'
                  }`}
                >
                  {tier.badge && (
                    <div className="absolute -top-3.5 left-8 inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-rose-600 to-orange-500 px-3.5 py-1 text-xs font-bold text-white shadow-sm">
                      <Sparkles className="h-3 w-3" />
                      <span>{tier.badge}</span>
                    </div>
                  )}

                  <div>
                    <h3 className="text-xl font-extrabold tracking-[-0.02em]">
                      {tier.name}
                    </h3>
                    <p
                      className={`mt-2 text-sm leading-relaxed ${
                        isPro ? 'text-zinc-400' : 'text-zinc-600'
                      }`}
                    >
                      {tier.tagline}
                    </p>

                    <div className="mt-6 flex items-baseline gap-1.5">
                      <AnimatePresence mode="wait">
                        <motion.span
                          key={`${tier.id}-${displayPrice}`}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -8 }}
                          transition={{ duration: 0.2 }}
                          className="text-4xl font-extrabold tracking-[-0.04em] sm:text-5xl"
                        >
                          ${displayPrice}
                        </motion.span>
                      </AnimatePresence>
                      <span
                        className={`text-sm font-medium ${
                          isPro ? 'text-zinc-400' : 'text-zinc-500'
                        }`}
                      >
                        {displayPrice === 0
                          ? '/ forever'
                          : annual
                          ? '/ mo, billed yearly'
                          : '/ month'}
                      </span>
                    </div>

                    <ul className="mt-7 space-y-3.5 border-t border-current/10 pt-6">
                      {tier.features.map((feat) => (
                        <li
                          key={feat}
                          className="flex items-start gap-3 text-sm leading-snug"
                        >
                          <Check
                            className={`mt-0.5 h-4 w-4 shrink-0 ${
                              isPro ? 'text-rose-400' : 'text-rose-600'
                            }`}
                          />
                          <span className={isPro ? 'text-zinc-200' : 'text-zinc-700'}>
                            {feat}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.015 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => onSelectPlan(tier.name)}
                    className={`mt-8 w-full rounded-full py-3.5 text-sm font-bold transition cursor-pointer ${
                      isPro
                        ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/25 hover:bg-rose-500'
                        : 'bg-zinc-950 text-white hover:bg-zinc-800'
                    }`}
                  >
                    {tier.ctaText}
                  </motion.button>
                </div>
              </SakugaItem>
            );
          })}
        </SakugaStagger>
      </div>
    </section>
  );
};
