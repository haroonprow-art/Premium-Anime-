import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence, useScroll, useSpring } from 'framer-motion';
import { Menu, X, Upload, ArrowRight } from 'lucide-react';
import { BrandLogo, SAKUGA_EASE } from './MotionPrimitives';

interface NavbarProps {
  onOpenModal: (mode: 'join' | 'share') => void;
}

const NAV_LINKS = [
  { label: 'Features', href: '#features' },
  { label: 'Showcase', href: '#showcase' },
  { label: 'Benefits', href: '#benefits' },
  { label: 'Community', href: '#testimonials' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'FAQ', href: '#faq' },
];

export const Navbar: React.FC<NavbarProps> = ({ onOpenModal }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 280,
    damping: 34,
    restDelta: 0.001,
  });

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? 'border-b border-zinc-900/[0.08] bg-white/80 shadow-[0_4px_24px_-8px_rgba(9,9,11,0.06)] backdrop-blur-xl'
          : 'border-b border-transparent bg-[#FAFAFA]/75 backdrop-blur-md'
      }`}
    >
      {/* Crisp scroll progress indicator */}
      <motion.div
        style={{ scaleX }}
        className="h-[2px] w-full origin-left bg-gradient-to-r from-rose-600 via-rose-500 to-orange-500"
      />

      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <a
          href="#"
          className="focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 rounded-lg"
          aria-label="AnimeFang Home"
        >
          <BrandLogo />
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1" aria-label="Primary Navigation">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-lg px-3.5 py-2 text-sm font-medium text-zinc-600 transition-colors duration-200 hover:bg-zinc-900/[0.04] hover:text-zinc-950"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center gap-3">
          <button
            type="button"
            onClick={() => onOpenModal('share')}
            className="inline-flex items-center gap-1.5 rounded-full border border-zinc-200 bg-white px-4 py-2 text-sm font-semibold text-zinc-800 shadow-2xs transition-all duration-200 hover:border-zinc-300 hover:bg-zinc-50 active:scale-[0.98] cursor-pointer"
          >
            <Upload className="h-3.5 w-3.5 text-rose-600" />
            <span>Share Clip</span>
          </button>

          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => onOpenModal('join')}
            className="inline-flex items-center gap-1.5 rounded-full bg-zinc-950 px-4.5 py-2 text-sm font-semibold text-white shadow-sm shadow-zinc-950/15 transition-colors hover:bg-rose-600 cursor-pointer"
          >
            <span>Join Free</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </motion.button>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          className="inline-flex items-center justify-center rounded-xl border border-zinc-200 bg-white p-2 text-zinc-700 md:hidden cursor-pointer"
          aria-expanded={mobileOpen}
          aria-label="Toggle Menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: SAKUGA_EASE }}
            className="overflow-hidden border-b border-zinc-200 bg-white md:hidden"
          >
            <div className="space-y-1 px-4 pt-3 pb-5">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="block rounded-xl px-3.5 py-2.5 text-base font-medium text-zinc-700 hover:bg-zinc-50 hover:text-zinc-950"
                >
                  {link.label}
                </a>
              ))}
              <div className="mt-4 grid grid-cols-2 gap-3 pt-3 border-t border-zinc-100">
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onOpenModal('share');
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-full border border-zinc-200 bg-white px-4 py-2.5 text-sm font-semibold text-zinc-800"
                >
                  <Upload className="h-4 w-4 text-rose-600" />
                  Share Clip
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onOpenModal('join');
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-full bg-zinc-950 px-4 py-2.5 text-sm font-semibold text-white"
                >
                  Join Free
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
