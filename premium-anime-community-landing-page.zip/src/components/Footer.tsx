import React from 'react';
import { BrandLogo } from './MotionPrimitives';

const FOOTER_COLUMNS = [
  {
    heading: 'Platform',
    links: [
      { label: 'Sakuga Clip Studio', href: '#features' },
      { label: 'Enemy & Rival Codex', href: '#showcase' },
      { label: 'Simulcast Watch Lounges', href: '#showcase' },
      { label: 'Episode Spoiler Shields', href: '#features' },
    ],
  },
  {
    heading: 'Community',
    links: [
      { label: 'Seasonal Rankings', href: '#showcase' },
      { label: 'Creator Guilds', href: '#testimonials' },
      { label: 'Discord Bot Sync', href: '#benefits' },
      { label: 'Membership Plans', href: '#pricing' },
    ],
  },
  {
    heading: 'Resources',
    links: [
      { label: '24fps Encoding Guide', href: '#benefits' },
      { label: 'Key Animator Index', href: '#features' },
      { label: 'Community Guidelines', href: '#faq' },
      { label: 'Help & FAQ', href: '#faq' },
    ],
  },
];

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-zinc-200/85 bg-white pt-16 pb-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-12">
          {/* Brand Column */}
          <div className="lg:col-span-5">
            <BrandLogo />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-zinc-600">
              Built for anime fans who care about every frame, every rivalry, and
              spoiler-free weekly watch parties.
            </p>
            <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1 text-xs font-medium text-zinc-600">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>Simulcast Nodes Online · Tokyo · US-West · Frankfurt</span>
            </div>
          </div>

          {/* Link Columns */}
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-7">
            {FOOTER_COLUMNS.map((col) => (
              <div key={col.heading}>
                <h3 className="text-xs font-bold tracking-wider text-zinc-950 uppercase">
                  {col.heading}
                </h3>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((item) => (
                    <li key={item.label}>
                      <a
                        href={item.href}
                        className="text-sm text-zinc-500 transition-colors hover:text-rose-600"
                      >
                        {item.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Legal Row */}
        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-zinc-100 pt-8 text-xs text-zinc-400 sm:flex-row">
          <p>© {new Date().getFullYear()} AnimeFang Community Inc. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#faq" className="hover:text-zinc-700">
              Privacy Policy
            </a>
            <a href="#faq" className="hover:text-zinc-700">
              Terms of Service
            </a>
            <a href="#faq" className="hover:text-zinc-700">
              Fair-Use Clip Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
