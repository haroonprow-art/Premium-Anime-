import React from 'react';
import { CheckCircle2, Zap, Shield, Layers } from 'lucide-react';
import {
  CelReveal,
  SakugaStagger,
  SakugaItem,
  AnimatedCounter,
} from './MotionPrimitives';

const METRICS = [
  { value: 184, suffix: 'K+', label: 'Active Anime Fans & Creators', decimals: 0 },
  { value: 2.4, suffix: 'M', label: 'Sakuga & Enemy Cuts Shared', decimals: 1 },
  { value: 99.8, suffix: '%', label: 'Spoiler-Shield Accuracy', decimals: 1 },
  { value: 95, prefix: '<', suffix: 'ms', label: 'Global Edge Clip Start', decimals: 0 },
];

const BENEFIT_POINTS = [
  {
    icon: Zap,
    title: 'Zero Bitrate Destruction on Dark & Fast Scenes',
    description:
      'Rain streaks, sword sparks, and nighttime Tokyo skylines keep every single line and gradient intact—no blocky artifacts ruining the climax.',
  },
  {
    icon: Layers,
    title: 'Structured Arcs, Episodes & Antagonist Vaults',
    description:
      'Instead of great clips vanishing into endless chat scrollback after ten minutes, every upload builds a permanent, searchable archive by episode and rival.',
  },
  {
    icon: Shield,
    title: 'Engage Together Without Walking Through Landmines',
    description:
      'Watch three hours after broadcast or binge two seasons behind—episode-level gating filters out late-arc reveals automatically.',
  },
];

export const BenefitsSection: React.FC = () => {
  return (
    <section id="benefits" className="py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Top Metrics Strip */}
        <SakugaStagger className="grid grid-cols-2 gap-6 rounded-3xl border border-zinc-200/85 bg-white p-8 shadow-2xs sm:p-10 lg:grid-cols-4">
          {METRICS.map((stat) => (
            <SakugaItem key={stat.label} className="text-center lg:text-left">
              <div className="text-3xl font-extrabold tracking-[-0.04em] text-zinc-950 sm:text-4xl lg:text-5xl">
                <AnimatedCounter
                  target={stat.value}
                  prefix={stat.prefix}
                  suffix={stat.suffix}
                  decimals={stat.decimals}
                />
              </div>
              <p className="mt-2 text-xs font-semibold text-zinc-500 sm:text-sm">
                {stat.label}
              </p>
            </SakugaItem>
          ))}
        </SakugaStagger>

        {/* Two-Column Editorial Split */}
        <div className="mt-20 grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-16">
          <CelReveal className="lg:col-span-6">
            <span className="text-xs font-bold tracking-[0.14em] text-rose-600 uppercase">
              Why Communities Switch
            </span>
            <h2 className="mt-3 text-3xl font-extrabold tracking-[-0.035em] text-zinc-950 sm:text-4xl lg:text-[42px] lg:leading-[1.12]">
              Built for passionate fandoms—not engagement-bait algorithms.
            </h2>
            <p className="mt-4 text-base leading-relaxed text-zinc-600">
              Mainstream timelines bury thoughtful breakdowns, crush dark animation frames,
              and spoil finale twists before you even get home from work. AnimeFang gives
              every series, episode, and iconic enemy the home it deserves.
            </p>

            <div className="mt-8 space-y-6">
              {BENEFIT_POINTS.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="flex items-start gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600 border border-rose-100">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-zinc-950">
                        {item.title}
                      </h3>
                      <p className="mt-1 text-sm leading-relaxed text-zinc-600">
                        {item.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CelReveal>

          {/* Right Side Visual Quality Comparison Card */}
          <CelReveal delay={0.12} className="lg:col-span-6">
            <div className="relative overflow-hidden rounded-3xl border border-zinc-200 bg-white p-5 shadow-xl shadow-zinc-950/[0.05] sm:p-7">
              <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
                <div>
                  <p className="text-xs font-bold tracking-wider text-zinc-400 uppercase">
                    Visual Fidelity Benchmark
                  </p>
                  <h3 className="text-lg font-bold text-zinc-950">
                    Night Scene & Particle Retention
                  </h3>
                </div>
                <span className="rounded-full bg-emerald-50 px-3 py-1 font-mono text-xs font-bold text-emerald-700">
                  +340% Bitrate Headroom
                </span>
              </div>

              <div className="mt-5 relative overflow-hidden rounded-2xl aspect-[16/10]">
                <img
                  src="/images/clip-cyber-shibuya.jpg"
                  alt="Tokyo Night Crossing High Bitrate Sample"
                  className="h-full w-full object-cover"
                />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                <div className="absolute bottom-3.5 left-3.5 right-3.5 flex flex-wrap items-center justify-between gap-2 text-white">
                  <div className="flex items-center gap-2 text-xs font-semibold">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    <span>10-Bit Color Gradient · Zero Shadow Banding</span>
                  </div>
                  <span className="rounded bg-white/15 px-2.5 py-0.5 font-mono text-[11px] backdrop-blur-md">
                    RAW STUDIO CADENCE
                  </span>
                </div>
              </div>

              {/* Comparison Checklist Row */}
              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-xl border border-zinc-200/75 bg-zinc-50 p-3.5">
                  <p className="text-xs font-semibold text-zinc-400">
                    Typical Social Feeds
                  </p>
                  <p className="mt-1 text-xs font-medium text-zinc-600">
                    30fps frame-blending smears, muddy shadows, zero spoiler gating
                  </p>
                </div>
                <div className="rounded-xl border border-rose-200 bg-rose-50/45 p-3.5">
                  <p className="text-xs font-bold text-rose-700">
                    AnimeFang Studio Stream
                  </p>
                  <p className="mt-1 text-xs font-semibold text-zinc-900">
                    True 24fps on-ones cuts, keyframe scrubber & episode protection
                  </p>
                </div>
              </div>
            </div>
          </CelReveal>
        </div>
      </div>
    </section>
  );
};
