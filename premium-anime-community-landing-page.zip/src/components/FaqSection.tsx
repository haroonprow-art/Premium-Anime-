import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import { FAQ_ITEMS } from '../data/animeContent';
import { CelReveal, SAKUGA_EASE } from './MotionPrimitives';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleItem = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  return (
    <section
      id="faq"
      className="border-t border-zinc-200/80 bg-[#FAFAFA] py-24 sm:py-32"
    >
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <CelReveal className="text-center">
          <span className="text-xs font-bold tracking-[0.14em] text-rose-600 uppercase">
            Questions & Answers
          </span>
          <h2 className="mt-3 text-3xl font-extrabold tracking-[-0.035em] text-zinc-950 sm:text-5xl">
            Frequently asked questions
          </h2>
          <p className="mt-4 text-base text-zinc-600">
            Everything you need to know about clip quality, spoiler shields, and community hubs.
          </p>
        </CelReveal>

        <div className="mt-12 space-y-3">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={item.question}
                className={`overflow-hidden rounded-2xl border bg-white transition-colors duration-200 ${
                  isOpen
                    ? 'border-zinc-300 shadow-sm'
                    : 'border-zinc-200/85 hover:border-zinc-300'
                }`}
              >
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => toggleItem(idx)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left cursor-pointer"
                >
                  <span className="text-sm font-bold text-zinc-950 sm:text-base">
                    {item.question}
                  </span>
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-colors ${
                      isOpen
                        ? 'bg-rose-600 text-white'
                        : 'bg-zinc-100 text-zinc-600'
                    }`}
                  >
                    {isOpen ? (
                      <Minus className="h-4 w-4" />
                    ) : (
                      <Plus className="h-4 w-4" />
                    )}
                  </span>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.28, ease: SAKUGA_EASE }}
                      className="overflow-hidden"
                    >
                      <div className="border-t border-zinc-100 px-6 pt-4 pb-6 text-sm leading-relaxed text-zinc-600">
                        {item.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
