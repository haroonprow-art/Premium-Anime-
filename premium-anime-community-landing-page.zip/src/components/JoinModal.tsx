import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle2, Upload, Sparkles, Shield } from 'lucide-react';
import { BrandLogo, SAKUGA_EASE } from './MotionPrimitives';

interface JoinModalProps {
  isOpen: boolean;
  initialMode: 'join' | 'share';
  prefilledHandle?: string;
  selectedPlan?: string;
  onClose: () => void;
}

export const JoinModal: React.FC<JoinModalProps> = ({
  isOpen,
  initialMode,
  prefilledHandle = '',
  selectedPlan = 'Community Fan',
  onClose,
}) => {
  const [mode, setMode] = useState<'join' | 'share'>(initialMode);
  const [handle, setHandle] = useState(prefilledHandle);
  const [email, setEmail] = useState('');
  const [clipTitle, setClipTitle] = useState('');
  const [seriesTag, setSeriesTag] = useState('Blade of the Vermilion Horizon · S2 EP 23');
  const [clipType, setClipType] = useState<'Sakuga Cut' | 'Enemy Showdown'>('Enemy Showdown');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    setMode(initialMode);
    setSubmitted(false);
  }, [initialMode, isOpen]);

  useEffect(() => {
    if (prefilledHandle) {
      setHandle(prefilledHandle);
    }
  }, [prefilledHandle]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', onKeyDown);
    }
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-zinc-950/55 backdrop-blur-xs"
          />

          {/* Modal Surface */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.24, ease: SAKUGA_EASE }}
            className="relative z-10 w-full max-w-md overflow-hidden rounded-3xl border border-zinc-200 bg-white p-6 shadow-2xl sm:p-8"
          >
            <div className="flex items-center justify-between">
              <BrandLogo size="sm" />
              <button
                type="button"
                onClick={onClose}
                aria-label="Close modal"
                className="rounded-full p-1.5 text-zinc-400 transition hover:bg-zinc-100 hover:text-zinc-800 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Mode Switch Tabs */}
            <div className="mt-5 grid grid-cols-2 gap-1 rounded-xl bg-zinc-100 p-1 text-xs font-bold">
              <button
                type="button"
                onClick={() => {
                  setMode('join');
                  setSubmitted(false);
                }}
                className={`rounded-lg py-2 transition cursor-pointer ${
                  mode === 'join'
                    ? 'bg-white text-zinc-950 shadow-2xs'
                    : 'text-zinc-500 hover:text-zinc-900'
                }`}
              >
                Join Community
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('share');
                  setSubmitted(false);
                }}
                className={`rounded-lg py-2 transition cursor-pointer ${
                  mode === 'share'
                    ? 'bg-white text-zinc-950 shadow-2xs'
                    : 'text-zinc-500 hover:text-zinc-900'
                }`}
              >
                Share Anime / Enemy Cut
              </button>
            </div>

            {submitted ? (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50/60 p-6 text-center"
              >
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-600 text-white">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-extrabold text-zinc-950">
                  {mode === 'join'
                    ? `Welcome aboard, @${handle || 'otaku_senpai'}!`
                    : 'Clip queued for 24fps Studio Encode!'}
                </h3>
                <p className="mt-1.5 text-xs leading-relaxed text-zinc-600">
                  {mode === 'join'
                    ? `Your ${selectedPlan} pass and episode spoiler shield preferences are ready.`
                    : `Tagged under ${clipType} (${seriesTag}) with automatic episode protection enabled.`}
                </p>
                <button
                  type="button"
                  onClick={onClose}
                  className="mt-5 w-full rounded-full bg-zinc-950 py-2.5 text-xs font-bold text-white hover:bg-rose-600 transition cursor-pointer"
                >
                  Back to Community Hub
                </button>
              </motion.div>
            ) : mode === 'join' ? (
              <form onSubmit={handleFormSubmit} className="mt-6 space-y-4">
                <div>
                  <h3 className="text-xl font-extrabold tracking-tight text-zinc-950">
                    Reserve your profile handle
                  </h3>
                  <p className="mt-1 text-xs text-zinc-500">
                    Selected tier: <strong className="text-rose-600">{selectedPlan}</strong>
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700">
                    Community Handle
                  </label>
                  <div className="mt-1.5 flex items-center rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 py-2.5 focus-within:border-rose-500 focus-within:bg-white">
                    <span className="font-mono text-xs text-zinc-400">@</span>
                    <input
                      type="text"
                      required
                      value={handle}
                      onChange={(e) => setHandle(e.target.value)}
                      placeholder="kenji_frames"
                      className="ml-1 w-full bg-transparent text-sm font-semibold text-zinc-950 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.com"
                    className="mt-1.5 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 py-2.5 text-sm text-zinc-950 focus:border-rose-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full bg-rose-600 py-3 text-sm font-bold text-white shadow-md shadow-rose-600/20 transition hover:bg-rose-700 cursor-pointer"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>Create Free Account</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleFormSubmit} className="mt-6 space-y-4">
                <div>
                  <h3 className="text-xl font-extrabold tracking-tight text-zinc-950">
                    Share a Clip or Enemy Showdown
                  </h3>
                  <p className="mt-1 text-xs text-zinc-500">
                    Lossless 10-bit WebM / MP4 · Auto-gated by episode tag
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {(['Enemy Showdown', 'Sakuga Cut'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setClipType(type)}
                      className={`rounded-xl border py-2 text-xs font-bold transition cursor-pointer ${
                        clipType === type
                          ? 'border-rose-500 bg-rose-50 text-rose-700'
                          : 'border-zinc-200 bg-zinc-50 text-zinc-600'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700">
                    Clip Title
                  </label>
                  <input
                    type="text"
                    required
                    value={clipTitle}
                    onChange={(e) => setClipTitle(e.target.value)}
                    placeholder="e.g., Unit-09 Boss Entrance Impact Cut"
                    className="mt-1.5 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 py-2.5 text-sm text-zinc-950 focus:border-rose-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700">
                    Series & Episode Spoiler Tag
                  </label>
                  <input
                    type="text"
                    required
                    value={seriesTag}
                    onChange={(e) => setSeriesTag(e.target.value)}
                    className="mt-1.5 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 py-2.5 text-sm text-zinc-950 focus:border-rose-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 rounded-xl bg-emerald-50/75 px-3 py-2 text-xs font-medium text-emerald-800">
                  <Shield className="h-4 w-4 shrink-0 text-emerald-600" />
                  <span>Spoiler Shield automatically enabled for un-caught-up fans</span>
                </div>

                <button
                  type="submit"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-zinc-950 py-3 text-sm font-bold text-white transition hover:bg-rose-600 cursor-pointer"
                >
                  <Upload className="h-4 w-4" />
                  <span>Publish to Community Feed</span>
                </button>
              </form>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
